==================================================
FormStack – Professional Business Forms
==================================================

Thank you for purchasing a FormStack template.

You now own a professionally designed, print-ready HTML business form built for real-world use in modern businesses.

--------------------------------------------------
WHAT IS THIS PRODUCT?
--------------------------------------------------

This product is a browser-based HTML form template that allows you to:

• Enter data directly in your browser
• Upload your company logo
• Change theme colors (if included)
• Print professionally to A4 paper
• Save as PDF
• Use offline after download

No software installation required.

--------------------------------------------------
HOW TO USE
--------------------------------------------------

1. Extract (unzip) the downloaded file.
2. Open the folder.
3. Double-click the .html file to open it in your web browser.

Recommended browsers:
✔ Google Chrome  
✔ Microsoft Edge  

4. Fill in the form fields.
5. Upload your logo using the logo box.
6. Choose a theme color (if available).
7. Click the “Print / Save PDF” button or press Ctrl + P.

--------------------------------------------------
PRINT SETTINGS (IMPORTANT)
--------------------------------------------------

For best results:

• Paper size: A4  
• Orientation: Portrait  
• Margins: Default  
• Enable: “Background graphics” or “Background colors”

To save as PDF:
Printer → “Save as PDF”

--------------------------------------------------
SYSTEM REQUIREMENTS
--------------------------------------------------

• Any modern web browser
• Windows / Mac / Linux
• No internet required after download

--------------------------------------------------
LICENSE SUMMARY
--------------------------------------------------

You ARE allowed to:

✔ Use this template for your own business
✔ Use it for client work
✔ Modify it for your own use

You are NOT allowed to:

✘ Resell the template files
✘ Share or redistribute the files
✘ Upload to other marketplaces
✘ Claim the design as your own

This product is licensed for personal and commercial use, but not for redistribution.

--------------------------------------------------
SUPPORT
--------------------------------------------------

If you experience any issues or have questions, please contact the seller through Gumroad.

--------------------------------------------------
ABOUT FORMSTACK
--------------------------------------------------

FormStack creates modern, practical, print-ready business forms for entrepreneurs, small businesses, and professionals.

Thank you for choosing FormStack.
